package com.workdocker.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsProductsApplicationTests {

	@Test
	void contextLoads() {
	}

}
